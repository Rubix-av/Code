# Creating the previous Todo app in Vue2

## User Login/Registration

**Use Authentication-Token for user login**

- [ ] Create database and datastore for users
- [ ] Enable users to register
- [ ] Redirect users to login page after registration
- [ ] After successful login, redirect user to profile page
